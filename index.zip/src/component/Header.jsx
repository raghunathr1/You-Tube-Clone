import { useState } from "react";
import { IoMenu } from "react-icons/io5";
import { FaSearch } from "react-icons/fa";
import { CgMathPlus } from "react-icons/cg";
import { IoMdNotificationsOutline } from "react-icons/io";
import { GrMicrophone } from "react-icons/gr";
import { FaUserAlt } from "react-icons/fa";
import FilterButton from "./FilterButton";
import { Link, useNavigate } from "react-router-dom";

function Header({
  toggleHide,
  search,
  setSearch,
  category,
  setCategory,
}) {
  const username = localStorage.getItem("username");

  const isLoggedIn =
    username &&
    username !== "undefined" &&
    username !== "null";

  const [showLogout, setShowLogout] = useState(false);

  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("username");

    navigate("/login");

    window.location.reload();
  };

  const handleCreate = () => {
    if (!localStorage.getItem("token")) {
      alert("Please Login First");
      navigate("/login");
      return;
    }

    navigate("/upload-video");
  };

  return (
    <>
      <nav className="nav">
        <div className="logoD">
          <button
            onClick={toggleHide}
            style={{
              border: "none",
              backgroundColor: "white",
              fontSize: "35px",
            }}
          >
            <IoMenu />
          </button>

          <div className="logo">
            <img
              src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/YouTube_Logo_2017.svg/1280px-YouTube_Logo_2017.svg.png"
              height="25px"
              width="100px"
              alt="Img"
            />
          </div>
        </div>

        <div>
          <input
            type="text"
            placeholder="Search"
            className="headInput"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <button id="headBtn">
            <FaSearch />
          </button>

          <button id="microPhone">
            <GrMicrophone />
          </button>
        </div>

        <div id="endBtn">
          {isLoggedIn ? (
            <div style={{ position: "relative" }}>
              <button
                className="createBtn"
                onClick={() =>
                  setShowLogout(!showLogout)
                }
              >
                {username}
              </button>

              {showLogout && (
                <button
                  onClick={handleLogout}
                  style={{
                    position: "absolute",
                    top: "45px",
                    right: "0",
                    padding: "8px 12px",
                    cursor: "pointer",
                  }}
                >
                  Logout
                </button>
              )}
            </div>
          ) : (
            <Link to="/login">
              <button className="createBtn">
                <FaUserAlt /> Sign In
              </button>
            </Link>
          )}

          <button
            className="createBtn"
            onClick={handleCreate}
          >
            <CgMathPlus /> Create
          </button>

          <button id="notification">
            <IoMdNotificationsOutline />
          </button>
        </div>
      </nav>

      <FilterButton
        category={category}
        setCategory={setCategory}
      />
    </>
  );
}

export default Header;