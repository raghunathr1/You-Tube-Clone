import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

function ChannelPage() {
  const { id } = useParams();

  const [channel, setChannel] = useState({});
  const [videos, setVideos] = useState([]);

  useEffect(() => {
    fetch(`http://localhost:4000/api/channel/${id}`)
      .then((res) => res.json())
      .then((data) => setChannel(data))
      .catch((err) => console.log(err));

    fetch(
      `http://localhost:4000/api/videos/channel/${id}`
    )
      .then((res) => res.json())
      .then((data) => setVideos(data))
      .catch((err) => console.log(err));
  }, [id]);

  return (
    <div style={{ padding: "20px" }}>
      <h1>{channel.channelName}</h1>

      <p>{channel.description}</p>

      <hr />

      <h2>Channel Videos</h2>

      {videos.length === 0 ? (
        <p>No Videos Uploaded Yet</p>
      ) : (
        videos.map((video) => (
          <div
            key={video._id}
            style={{
              marginBottom: "20px",
            }}
          >
            <h3>{video.title}</h3>

            <img
              src={video.thumbnailUrl}
              alt={video.title}
              width="250"
            />

            <p>{video.category}</p>

            <p>{video.views} Views</p>
          </div>
        ))
      )}
    </div>
  );
}

export default ChannelPage;